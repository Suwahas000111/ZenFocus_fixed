package com.zenfocus.app

import android.app.Activity
import android.app.PictureInPictureParams
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.view.WindowManager
import android.webkit.WebSettings
import android.webkit.JavascriptInterface
import android.content.Intent
import android.os.Build
import android.Manifest
import android.content.pm.PackageManager
import android.util.Rational
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView
    private inner class ZenFocusBridge {
        @JavascriptInterface fun setKeepScreenOn(enabled:Boolean){runOnUiThread{if(enabled)window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)}}
        @JavascriptInterface fun startTimer(seconds:Long,mode:String){val i=Intent(this@MainActivity,FocusTimerService::class.java).setAction(FocusTimerService.ACT_START).putExtra("seconds",seconds).putExtra("mode",mode);if(Build.VERSION.SDK_INT>=26)startForegroundService(i)else startService(i)}
        @JavascriptInterface fun pauseTimer(seconds:Long){startService(Intent(this@MainActivity,FocusTimerService::class.java).setAction(FocusTimerService.ACT_PAUSE).putExtra("seconds",seconds))}
        @JavascriptInterface fun stopTimer(){startService(Intent(this@MainActivity,FocusTimerService::class.java).setAction(FocusTimerService.ACT_STOP))}
        @JavascriptInterface fun enterPip(){runOnUiThread{if(Build.VERSION.SDK_INT>=26){try{enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16,9)).build())}catch(e:Exception){Toast.makeText(this@MainActivity,"PIP unavailable on this device",Toast.LENGTH_SHORT).show()}}else Toast.makeText(this@MainActivity,"PIP requires Android 8 or newer",Toast.LENGTH_SHORT).show()}}
    }
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);window.statusBarColor=android.graphics.Color.rgb(7,8,12);window.navigationBarColor=android.graphics.Color.rgb(7,8,12);web=WebView(this);web.setBackgroundColor(android.graphics.Color.rgb(7,8,12));web.webViewClient=WebViewClient();web.webChromeClient=WebChromeClient();web.settings.javaScriptEnabled=true;web.settings.domStorageEnabled=true;web.settings.cacheMode=WebSettings.LOAD_DEFAULT;web.settings.allowFileAccess=true;web.settings.allowContentAccess=true;web.addJavascriptInterface(ZenFocusBridge(),"ZenFocusAndroid");setContentView(web);web.loadUrl("file:///android_asset/index.html");if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),71)}
    override fun onBackPressed(){if(::web.isInitialized&&web.canGoBack())web.goBack()else super.onBackPressed()}
    override fun onDestroy(){if(::web.isInitialized)web.destroy();window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);super.onDestroy()}
}
