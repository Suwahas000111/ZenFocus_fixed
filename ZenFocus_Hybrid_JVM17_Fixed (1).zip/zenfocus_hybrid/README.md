# ZenFocus Hybrid Android Project

This project keeps the original ZenFocus HTML/CSS/JavaScript interface inside an Android WebView. The original layout, colors, controls, sounds, tasks, analytics and local-storage experience are retained as the UI foundation.

## Android additions
- Native foreground countdown service with an ongoing notification while a timer is running.
- Pause/resume and stop controls in the timer notification.
- Timer completion notification if the app is in the background.
- Native Screen Awake bridge (the existing HTML toggle controls the Android keep-screen-on flag).
- Picture-in-Picture entry button (Android 8.0+; availability depends on device settings).
- Study-day key rolls over at 4:00 AM local time.

## Build
Open this folder as an Android project in Android Studio or import it into a compatible Android build service. Use JDK 17 or newer. The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile SDK 35, and AndroidX Core KTX 1.15.0.

## Notes
The timer service and the WebView timer are synchronized when starting, pausing, resetting, or switching modes from the app UI. The notification can keep counting while the app is backgrounded. Notification actions operate on the native service; if you pause/resume from the notification, reopen the app to let its page UI catch up before interacting further.

This is a source project, not a signed APK. A full device build/test is still required. Picture-in-Picture behavior and notification permission prompts can vary by Android version and manufacturer.
