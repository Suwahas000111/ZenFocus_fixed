package com.zenfocus.app

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.Manifest
import android.util.Rational
import android.webkit.*
import android.view.WindowManager

class MainActivity : Activity() {
    private lateinit var web: WebView
    private inner class ZenFocusBridge {
        @JavascriptInterface fun setKeepScreenOn(enabled: Boolean) = runOnUiThread {
            if (enabled) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        @JavascriptInterface fun startNativeTimer(seconds: Int, mode: String) {
            val intent = Intent(this@MainActivity, FocusTimerService::class.java).apply {
                action = FocusTimerService.ACTION_START
                putExtra("seconds", seconds.coerceAtLeast(0).toLong())
                putExtra("mode", mode.take(30))
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        }
        @JavascriptInterface fun pauseNativeTimer() {
            startService(Intent(this@MainActivity, FocusTimerService::class.java).setAction(FocusTimerService.ACTION_PAUSE))
        }
        @JavascriptInterface fun stopNativeTimer() {
            startService(Intent(this@MainActivity, FocusTimerService::class.java).setAction(FocusTimerService.ACTION_STOP))
        }
        @JavascriptInterface fun enterPip() = runOnUiThread {
            if (Build.VERSION.SDK_INT >= 26 && packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
                enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 701)
        }
        window.statusBarColor = android.graphics.Color.rgb(7, 8, 12)
        window.navigationBarColor = android.graphics.Color.rgb(7, 8, 12)
        web = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(7, 8, 12))
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            addJavascriptInterface(ZenFocusBridge(), "ZenFocusAndroid")
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
    override fun onDestroy() {
        if (::web.isInitialized) web.destroy()
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        super.onDestroy()
    }
}
