# ZenFocus V2.4 — Error 70 maintenance build

This Android WebView project retains the existing ZenFocus HTML interface and applies targeted fixes:
- Immersive fullscreen hides Android status and navigation bars, with swipe-to-reveal behavior.
- Timer state is saved separately and restored when the WebView/app is reopened.
- Added an in-app Study Do Not Disturb toggle that suppresses the app's completion alarm.
- Disabled WebView pinch zoom and restricted page zoom through the viewport.
- Existing CSV history export and JSON backup/import controls remain in place.

Build with Gradle 8.9 and Java 17. Test on the target Android device. Android notification permission, battery optimization, and manufacturer background limits can affect background behavior.

Note: this is a source project, not a prebuilt APK. The in-app DND toggle does not change the phone's system-wide Do Not Disturb setting.
