# ZenFocus V2.4 — Error 70 maintenance build

This Android WebView project retains the existing ZenFocus HTML interface and applies targeted fixes:
- Immersive fullscreen hides Android status and navigation bars, with swipe-to-reveal behavior.
- Timer state is saved separately and restored when the WebView/app is reopened.
- Added an in-app Study Do Not Disturb toggle that suppresses the app's completion alarm.
- Disabled WebView pinch zoom and restricted page zoom through the viewport.
- Existing CSV history export and JSON backup/import controls remain in place.

Build with Gradle 8.9 and Java 17. Test on the target Android device. Android notification permission, battery optimization, and manufacturer background limits can affect background behavior.

Note: this is a source project, not a prebuilt APK. The in-app DND toggle does not change the phone's system-wide Do Not Disturb setting.


## Error 70 maintenance changes (source update)
- Zen Mode now hides the fixed in-app bottom navigation as well as requesting Android immersive system bars.
- Normal Android window layout now fits system bars to avoid the app title overlapping the status bar.
- Timer state is saved periodically and on lifecycle changes; an expired focus timer is finalized on next launch so its session can be logged once.
- Reset now resets the current phase instead of accidentally restoring an old saved timer.
- In-app Study DND suppresses the app's alarm sound and browser notification.
- CSV history and JSON backup export use the Android download bridge on supported Android versions; backup file selection is enabled in WebView.
- Backup now includes saved timer state and DND/haptics preferences.
- Settings are visually grouped for easier navigation.

Validation performed: JavaScript syntax checked with Node.js and HTML checked for duplicate element IDs. An Android Gradle build and on-device test were not run in this environment.
