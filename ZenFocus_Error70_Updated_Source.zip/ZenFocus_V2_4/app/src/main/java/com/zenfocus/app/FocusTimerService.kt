package com.zenfocus.app

import android.app.* 
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat

class FocusTimerService : Service() {
    private var endAt = 0L
    private var remaining = 0L
    private var running = false
    private var mode = "focus"
    private val channel = "zenfocus_timer"
    private val notifId = 2041

    override fun onCreate() { super.onCreate(); createChannel() }
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACT_START -> { remaining = intent.getLongExtra("seconds", 0).coerceAtLeast(0); mode = intent.getStringExtra("mode") ?: "focus"; running = true; endAt = SystemClock.elapsedRealtime()+remaining*1000; startForeground(notifId, notification()); tick() }
            ACT_PAUSE -> { if(running) remaining=((endAt-SystemClock.elapsedRealtime())/1000).coerceAtLeast(0); running=false; update() }
            ACT_RESUME -> { if(!running && remaining>0){running=true;endAt=SystemClock.elapsedRealtime()+remaining*1000;update();tick()} }
            ACT_STOP -> { stopForeground(STOP_FOREGROUND_REMOVE);stopSelf() }
        }
        return START_NOT_STICKY
    }
    private fun tick(){ Thread { while(running){remaining=((endAt-SystemClock.elapsedRealtime())/1000).coerceAtLeast(0);update();if(remaining<=0){running=false;stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();break};Thread.sleep(1000)} }.start() }
    private fun createChannel(){if(Build.VERSION.SDK_INT>=26){val c=NotificationChannel(channel,"ZenFocus study timer",NotificationManager.IMPORTANCE_LOW);c.description="Ongoing focus countdown";getSystemService(NotificationManager::class.java).createNotificationChannel(c)}}
    private fun action(label:String,act:String):PendingIntent{val i=Intent(this,FocusTimerService::class.java).setAction(act);return PendingIntent.getService(this,act.hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)}
    private fun notification():Notification{
        val open=PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val title=if(mode=="focus")"ZenFocus · Focus session" else "ZenFocus · Break"
        val n=NotificationCompat.Builder(this,channel).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(title).setContentText(if(running)"Timer running · ${format(remaining)} remaining" else "Paused · ${format(remaining)} remaining").setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true).setVisibility(NotificationCompat.VISIBILITY_PUBLIC).addAction(android.R.drawable.ic_media_pause,if(running)"Pause" else "Resume",action(if(running)"Pause" else "Resume",if(running)ACT_PAUSE else ACT_RESUME)).build()
        if(running){n.flags=n.flags or Notification.FLAG_NO_CLEAR};return n
    }
    private fun update(){getSystemService(NotificationManager::class.java).notify(notifId,notification())}
    private fun format(s:Long)="%02d:%02d:%02d".format(s/3600,(s%3600)/60,s%60)
    companion object{const val ACT_START="zf.start";const val ACT_PAUSE="zf.pause";const val ACT_RESUME="zf.resume";const val ACT_STOP="zf.stop"}
}
