package com.zenfocus.app

import android.app.Activity
import android.app.PictureInPictureParams
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.view.WindowManager
import android.webkit.WebSettings
import android.webkit.JavascriptInterface
import android.content.Intent
import android.os.Build
import android.Manifest
import android.content.pm.PackageManager
import android.util.Rational
import android.widget.Toast
import android.os.VibrationEffect
import android.os.Vibrator
import android.content.Context
import android.content.ContentValues
import android.net.Uri
import android.provider.MediaStore
import android.os.Environment
import android.util.Base64
import android.webkit.ValueCallback
import androidx.core.view.WindowCompat

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private inner class ZenFocusBridge {
        @Suppress("DEPRECATION")
        @JavascriptInterface fun vibrate(milliseconds:Long){runOnUiThread{try{val v=getSystemService(Context.VIBRATOR_SERVICE) as Vibrator;if(v.hasVibrator()){if(Build.VERSION.SDK_INT>=26)v.vibrate(VibrationEffect.createOneShot(milliseconds.coerceIn(10,60),VibrationEffect.DEFAULT_AMPLITUDE))else v.vibrate(milliseconds.coerceIn(10,60))}}catch(e:Exception){}}}
        @JavascriptInterface fun setImmersive(enabled:Boolean){runOnUiThread{applyImmersive(enabled)}}
        @JavascriptInterface fun setKeepScreenOn(enabled:Boolean){runOnUiThread{if(enabled)window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)}}
        @JavascriptInterface fun downloadFile(filename:String,mimeType:String,base64Data:String){
            runOnUiThread {
                try {
                    val bytes = Base64.decode(base64Data, Base64.DEFAULT)
                    if (Build.VERSION.SDK_INT >= 29) {
                        val values = ContentValues().apply {
                            put(MediaStore.Downloads.DISPLAY_NAME, filename.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                            put(MediaStore.Downloads.MIME_TYPE, mimeType)
                            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ZenFocus")
                            put(MediaStore.Downloads.IS_PENDING, 1)
                        }
                        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                            ?: throw IllegalStateException("Could not create download")
                        contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                            ?: throw IllegalStateException("Could not write download")
                        values.clear()
                        values.put(MediaStore.Downloads.IS_PENDING, 0)
                        contentResolver.update(uri, values, null, null)
                        Toast.makeText(this@MainActivity, "Saved to Downloads/ZenFocus", Toast.LENGTH_LONG).show()
                    } else {
                        val dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: filesDir
                        val file = java.io.File(dir, filename.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                        file.writeBytes(bytes)
                        Toast.makeText(this@MainActivity, "Saved: " + file.absolutePath, Toast.LENGTH_LONG).show()
                    }
                } catch (e:Exception) {
                    Toast.makeText(this@MainActivity, "Export failed: " + (e.message ?: "unknown error"), Toast.LENGTH_LONG).show()
                }
            }
        }
        @JavascriptInterface fun startTimer(seconds:Long,mode:String){val i=Intent(this@MainActivity,FocusTimerService::class.java).setAction(FocusTimerService.ACT_START).putExtra("seconds",seconds).putExtra("mode",mode);if(Build.VERSION.SDK_INT>=26)startForegroundService(i)else startService(i)}
        @JavascriptInterface fun pauseTimer(seconds:Long){startService(Intent(this@MainActivity,FocusTimerService::class.java).setAction(FocusTimerService.ACT_PAUSE).putExtra("seconds",seconds))}
        @JavascriptInterface fun stopTimer(){startService(Intent(this@MainActivity,FocusTimerService::class.java).setAction(FocusTimerService.ACT_STOP))}
        @JavascriptInterface fun enterPip(){runOnUiThread{if(Build.VERSION.SDK_INT>=26){try{enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16,9)).build())}catch(e:Exception){Toast.makeText(this@MainActivity,"PIP unavailable on this device",Toast.LENGTH_SHORT).show()}}else Toast.makeText(this@MainActivity,"PIP requires Android 8 or newer",Toast.LENGTH_SHORT).show()}}
    }
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);WindowCompat.setDecorFitsSystemWindows(window,true);window.statusBarColor=android.graphics.Color.rgb(7,8,12);window.navigationBarColor=android.graphics.Color.rgb(7,8,12);web=WebView(this);web.setBackgroundColor(android.graphics.Color.rgb(7,8,12));web.webViewClient=WebViewClient();web.webChromeClient=object:WebChromeClient(){
            override fun onShowFileChooser(view:WebView, callback:ValueCallback<Array<Uri>>, params:FileChooserParams):Boolean {
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback=callback
                return try {
                    val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type="*/*"
                    }
                    startActivityForResult(intent,72)
                    true
                } catch(e:Exception) {
                    fileChooserCallback=null
                    false
                }
            }
        };web.settings.javaScriptEnabled=true;web.settings.setSupportZoom(false);web.settings.builtInZoomControls=false;web.settings.displayZoomControls=false;web.settings.domStorageEnabled=true;web.settings.cacheMode=WebSettings.LOAD_DEFAULT;web.settings.allowFileAccess=true;web.settings.allowContentAccess=true;web.addJavascriptInterface(ZenFocusBridge(),"ZenFocusAndroid");setContentView(web);web.loadUrl("file:///android_asset/index.html");if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),71)}
    private var immersiveEnabled = false
    private fun applyImmersive(enabled:Boolean) {
        immersiveEnabled = enabled
        // Android 15 enforces edge-to-edge for targetSdk 35. Explicitly fit
        // content to system windows outside Zen Mode to prevent title/status overlap.
        WindowCompat.setDecorFitsSystemWindows(window, !enabled)
        if (Build.VERSION.SDK_INT >= 30) {
            val controller = window.insetsController ?: return
            if (enabled) {
                controller.hide(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior = android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            } else {
                controller.show(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = if (enabled)
                (android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
                 android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                 android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                 android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
            else android.view.View.SYSTEM_UI_FLAG_VISIBLE
        }
    }
    override fun onWindowFocusChanged(hasFocus:Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && immersiveEnabled) applyImmersive(true)
    }
    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==72) {
            val result=if(resultCode==Activity.RESULT_OK && data?.data!=null) arrayOf(data.data!!) else null
            fileChooserCallback?.onReceiveValue(result)
            fileChooserCallback=null
        }
    }
    override fun onBackPressed(){if(::web.isInitialized&&web.canGoBack())web.goBack()else super.onBackPressed()}
    override fun onDestroy(){if(::web.isInitialized)web.destroy();window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);super.onDestroy()}
}
