plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.zenfocus.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.zenfocus.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 4
        versionName = "2.4"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies { implementation("androidx.core:core-ktx:1.15.0") }
