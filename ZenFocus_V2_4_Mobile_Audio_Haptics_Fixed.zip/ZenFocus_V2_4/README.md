# ZenFocus V2.3 — Android WebView project

This upgrade keeps the V2.2 HTML/CSS/JavaScript interface and wraps it in the Android WebView app.

## Included
- Original ZenFocus Ultra visual style retained.
- Bottom navigation: Timer, Music, Schedule, Analyze, Settings.
- Music library categories and ambient sound controls.
- 7-day, 14-day and monthly analytics.
- Ten timer visual styles and theme choices.
- Task queue with optional due dates and overdue (MISSED) labels.
- Session history, CSV export, JSON backup/import.
- Picture-in-picture bridge, screen-awake bridge and native foreground timer notification service.
- Daily study counter rolls over at 04:00 local device time.
- Java and Kotlin bytecode targets aligned to JVM 17 for GitHub Actions.

## Build
Use GitHub Actions with Gradle 8.9 and Java 17. The project root is the folder containing `settings.gradle.kts`.

Note: This is a source project, not a prebuilt APK. Test notifications, PIP, and background timer behavior on the target Android device. Android may apply battery/background restrictions depending on device settings.
